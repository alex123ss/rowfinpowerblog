/**
 * @file
 * Queryly search block
 */
(($, Drupal) => {

  /**
   * Initialize the queryly function.
   */
  Drupal.behaviors.initializeQueryly = {
    attach: function (context, settings) {
      queryly.init("ddcbe85e6bce42f7", document.querySelectorAll('header,footer,.container'));
      // GA events for Queryly
      setTimeout(function() {
        jQuery(document).ready(function() {
          var queryly_attr = jQuery('body').attr('data-queryly_hideimage');
          if (typeof queryly_attr !== 'undefined' && queryly_attr == "true") {
            // -- Search images are hidden.
            jQuery('.queryly_search_button').click(function() {
              console.log('Queryly w/o Image: Search icon clicked');
              window.dataLayer = window.dataLayer || [];
              window.dataLayer.push({
                'event': 'custom_event', //DO NOT CHANGE
                'eventCategory': 'search result with no-image',
                'eventAction': 'visible',
                'eventLabel': '',
                'nonInteraction': true
              });
            });
            jQuery(document).on('click', '.queryly_item_innercontainer a.resultlink', function() {
              console.log('Queryly w/o Image: Search result clicked');
              window.dataLayer = window.dataLayer || [];
              window.dataLayer.push({
                'event': 'custom_event', //DO NOT CHANGE
                'eventCategory': 'search result with no-image',
                'eventAction': 'click',
                'eventLabel': jQuery(this).attr('href'),
                'nonInteraction': false
              });
            });
            if (jQuery('body').hasClass('page-search') && jQuery('#queryly_advanced_container').length > 0) {
              console.log('Queryly w/o Image: Advanced Search page viewed');
              window.dataLayer = window.dataLayer || [];
              window.dataLayer.push({
                'event': 'custom_event', //DO NOT CHANGE
                'eventCategory': 'search result with no-image',
                'eventAction': 'visible',
                'eventLabel': '',
                'nonInteraction': true
              });
            }
            jQuery(document).on('click', '#queryly_advanced_container .queryly_item_row a', function() {
              console.log('Queryly w/o Image: Advanced Search result clicked');
              window.dataLayer = window.dataLayer || [];
              window.dataLayer.push({
                'event': 'custom_event', //DO NOT CHANGE
                'eventCategory': 'search result with no-image',
                'eventAction': 'click',
                'eventLabel': jQuery(this).attr('href'),
                'nonInteraction': false
              });
            });
          } else {
            // -- Search images are visible
            jQuery('.queryly_search_button').click(function() {
              console.log('Queryly with Image: Search icon clicked');
              window.dataLayer = window.dataLayer || [];
              window.dataLayer.push({
                'event': 'custom_event', //DO NOT CHANGE
                'eventCategory': 'search result with image',
                'eventAction': 'visible',
                'eventLabel': '',
                'nonInteraction': true, //true -> non interactive event (no impact on bounce rate), false -> interactive event (lower bounce rate)
              });
            });
            jQuery(document).on('click', '.queryly_item_innercontainer a.resultlink', function() {
              console.log('Queryly with Image: Search result clicked');
              window.dataLayer = window.dataLayer || [];
              window.dataLayer.push({
                'event': 'custom_event',
                'eventCategory': 'search result with image',
                'eventAction': 'click',
                'eventLabel': jQuery(this).attr('href'),
                'nonInteraction': false
              });
            });
            if (jQuery('body').hasClass('page-search') && jQuery('#queryly_advanced_container').length > 0) {
              console.log('Queryly with Image: Advanced Search page viewed');
              window.dataLayer = window.dataLayer || [];
              window.dataLayer.push({
                'event': 'custom_event', //DO NOT CHANGE
                'eventCategory': 'search result with image',
                'eventAction': 'visible',
                'eventLabel': '',
                'nonInteraction': true
              });
            }
            jQuery(document).on('click', '#queryly_advanced_container .queryly_item_row a', function() {
              console.log('Queryly with Image: Advanced Search result clicked');
              window.dataLayer = window.dataLayer || [];
              window.dataLayer.push({
                'event': 'custom_event', //DO NOT CHANGE
                'eventCategory': 'search result with image',
                'eventAction': 'click',
                'eventLabel': jQuery(this).attr('href'),
                'nonInteraction': false
              });
            })
          }
        });
        console.log('after 3 sec, waiting for GA to load the AB test');
        }, 3000);
    }
  };

})(jQuery, Drupal);
