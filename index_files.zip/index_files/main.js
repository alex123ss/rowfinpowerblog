const domains = ["awsdev.businesstimes.com.sg", "uat.businesstimes.com.sg", "www.businesstimes.com.sg"];
if (location.protocol == 'https:' && drupalSettings.user.uid == 0 && drupalSettings.path.currentPath != "user/login" && domains.includes(location.host)) {
  // web app's Firebase configuration

  var fC = {
    apiKey: atob(drupalSettings.PAK),
    authDomain: atob(drupalSettings.PAD),
    databaseURL: atob(drupalSettings.PDU),
    projectId: atob(drupalSettings.PID),
    storageBucket: atob(drupalSettings.PSB),
    messagingSenderId: atob(drupalSettings.PMS),
    appId: atob(drupalSettings.PAI)
  };
  // Initialize Firebase
  firebase.initializeApp(fC);

  // Request permission and get token....
  function permissions(messaging) {
    messaging.requestPermission().then(function () {
      console.log('Notification permission granted.');
      return messaging.getToken();
    }).then(function (token) {
      console.log('Device token: ' + token);
      //subscribe to topic
      subscribeTokenToTopic(token, atob(drupalSettings.PTT));
    }).catch(function (err) {
      console.log('Unable to get permission to notify.', err);
    });
  }

  function subscribeTokenToTopic(token, topic) {
    fetch('https://iid.googleapis.com/iid/v1/' + token + '/rel/topics/' + topic, {
      method: 'POST',
      headers: new Headers({
        'Authorization': 'key=' + atob(drupalSettings.PSK)
      })
    }).then(response => {
      if (response.status < 200 || response.status >= 400) {
        throw 'Error subscribing to topic: ' + response.status + ' - ' + response.text();
      }
      console.log('Subscribed to "' + topic + '"');
    }).catch(error => {
      console.error(error);
    })
  }

  if (firebase.messaging.isSupported()) {
    // Retrieve Firebase Messaging object.
    const messaging = firebase.messaging();
    messaging.usePublicVapidKey(atob(drupalSettings.PPV));
    permissions(messaging);
  }

}

