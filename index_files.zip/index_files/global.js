/**
 * @file
 * Global utilities.
 *
 */
(function ($, Drupal) {

  'use strict';

  Drupal.elementIsVisibleInViewport = (el, partiallyVisible = false) => {
    if (!el) return false;

    const { top, left, bottom, right } = el.getBoundingClientRect();
    const { innerHeight, innerWidth } = window;
    return partiallyVisible
      ? ((top > 0 && top < innerHeight) ||
          (bottom > 0 && bottom < innerHeight)) &&
          ((left > 0 && left < innerWidth) || (right > 0 && right < innerWidth))
      : top >= 0 && left >= 0 && bottom <= innerHeight && right <= innerWidth;
  };

  /**
   * Adds controls and indicators to any carouse, if needed and
   * adds active classs to the first carousel-slide.
   */
  Drupal.behaviors.carouselSettings = {
    attach: function (context, settings) {
      // Finds any carousel.
      var $carousel = $(".carousel.slide");

      // Loops through each carousel.
      $carousel.each(function () {
        // Instantiate the variables.
        let $this = $(this);
        let hasControls = $this.data("bs-controls") === true;
        let hasIndicators = $this.data("bs-indicators") === true;
        let id = $this.attr("id");
        let no_of_slides = $this.find(".carousel-inner").children().length || 0;

        // Adds active class to first carousel-slide.
        $this.find(".carousel-item:first-child").addClass("active");

        // Adds controls.
        if (hasControls && no_of_slides > 1) {
          // Creates the previous icon.
          let prevIcon = $("<span>").attr({
            "class": "carousel-control-prev-icon",
            "aria-hidden": "true",
          });

          // Creates the previous button.
          let prevButton = $("<button>").attr({
            "class": "carousel-control-prev",
            "type": "button",
            "data-bs-target": "#" + id,
            "data-bs-slide": "prev"
          }).append(prevIcon);

          // Creates the next icon.
          let nextIcon = $("<span>").attr({
            "class": "carousel-control-next-icon",
            "aria-hidden": "true",
          });

          // Creates the next button.
          let nextButton = $("<button>").attr({
            "class": "carousel-control-next",
            "type": "button",
            "data-bs-target": "#" + id,
            "data-bs-slide": "next"
          }).append(nextIcon);

          // Finallly, appends previous and next button to the carousel.
          $this.append(prevButton, nextButton);
        }

        // Adds indicators.
        if (hasIndicators) {
          // Counts how many slides are there.
          let slides = $this.find(".carousel-inner").children().length;

          // Instantiate the carousel-indicators.
          let $indicators = $("<div>").attr({
            "class": "carousel-indicators",
          });

          // Loops through the number of slides.
          for (let i = 0; i < slides; i++) {
            // Creates the indicator per slide.
            let $indicator = $("<button>").attr({
              "type": "button",
              "data-bs-target": "#" + id,
              "data-bs-slide-to": i,
              "aria-label": "Slide " + i,
            });

            // Adds attribute specific to the first indicator.
            if (i == 0) {
              $indicator.attr({
                "class": "active",
                "aria-current": "true",

              });
            }

            // Appends the indicator to carousel-indicators.
            $indicators.append($indicator);
          }

          // Finally, appends carousel-indicators to the carousel.
          $this.append($indicators);
        }
      });
    }
  };

  /**
   * Activates breadcrumbs.
   */
  Drupal.behaviors.activateBreadcrumbs = {
    attach: function (context, settings) {
      let $breadcrumbs = $("#breadcrumbs");
      let $parent = $breadcrumbs.find(".parent-wrapper");
      let mobile = window.matchMedia("(max-width: 991px)");
      let desktop = window.matchMedia("(min-width: 992px)");

      let $splide = $breadcrumbs.find(".splide");
      if ($splide.length > 0) {
        // Initialize slider with settings.
        const splide = new Splide("#breadcrumbs .splide", {
          type: "slide",
          autoWidth: true,
          pagination: false,
          snap: true,
          gap: "1rem",
          width: "100%",
          padding: "2rem",
          breakpoints: {
            768: {
              arrows: false,
              padding: "1rem",
            }
          }
        }).mount();

        initial_start();

        /**
         * Hide splide arrows if total width of splide__slide is smaller than splide__track.
         */
        function initial_start() {
          if ($parent.length > 0) {
            let parent_width = $parent.outerWidth(true);
            $breadcrumbs.find(".splide-wrapper").css("width", "calc(100% - " + parent_width + "px)");
          }

          let $splide_track = $breadcrumbs.find(".splide__track");
          let track_width = $splide_track.width() || 0;
          let children_width = -25;
          $breadcrumbs.find(".splide__slide:not(.parent)").each(function () {
            children_width += $(this).outerWidth(true);
          });

          if (children_width <= track_width) {
            $splide_track.addClass("no-controls");
            splide.options = {
              arrows: false,
              padding: "1rem",
            };
          } else {
            if (desktop.matches) {
              $splide_track.removeClass("no-controls");
              splide.options = {
                arrows: true,
                padding: "3rem",
              };
            }
          }

          let $parentInside = $("#breadcrumbs .splide .taxonomy-term--view-mode-breadcrumb-parent");
          if (mobile.matches) {
            if ($parentInside.length <= 0) {
              if ($parent.hasClass("active-path")) {
                $parent.find(".taxonomy-term--view-mode-breadcrumb-parent").addClass("active-path");
              }
              splide.add($parent.get(0).innerHTML, 0);
            }
          }

          if (desktop.matches) {
            if ($parentInside.length > 0) {
              $parent.find(".taxonomy-term--view-mode-breadcrumb-parent").remove("active-path");
              splide.remove(0);
            }
          }

          // Put active child item in view.
          $breadcrumbs.find(".splide__slide").each(function (index) {
            if ($(this).hasClass("active-path")) {
              splide.go(index - 1);
            }
          });
        }

        /**
         * Call the hidearrow function everytime window resizes.
         */
        $(window).resize(function () {
          initial_start();
        });
      }
    }
  };

  /**
   * Add click event for navigations. Accordion and navbar.
   */
  Drupal.behaviors.accordionNavbarLink = {
    attach: function (context, settings) {
      let accordionNavbarLink = function () {
        let target = $(this).attr("href");

        // For some browsers, `attr` is undefined; for others,
        // `attr` is false.  Check for both.
        if (typeof target !== 'undefined' && target !== false) {
          window.location.href = target;
        }

        return false;
      }

      // Add click event on side menu to open the link when clicked.
      $("body").on(
        "click",
        "#block-sidemenu .accordion-button > a, .left-menu a.dropdown-toggle",
        accordionNavbarLink
      );
    }
  };

  /**
   * Initialize main image magnific popup links.
   */
  Drupal.behaviors.articleInlineImageMfp = {
    attach: function (context, settings) {
      if ($.isFunction($.fn.magnificPopup)) {
        $(".paragraph--type-image figure").each(function () {
          if ($(this).children().prop("tagName") != "A") {
            var img = $(this).find('img');
            var mfp = img.attr("src");
            var cap = img.siblings("figcaption").html() ? img.siblings("figcaption").html() : '';
            img.wrap("<a class=\"mfp\" data-caption=\"" + cap + "\" href=\"" + mfp + "\"></a>");
          }
        });

        $('.mfp').magnificPopup({
          type: 'image',
          gallery: {
            enabled: true
          },
          image: {
            titleSrc: function (item) {
              return item.el.attr("data-caption");
            }
          },
          zoom: {
            enabled: true, // By default it's false, so don't forget to enable it

            duration: 300, // duration of the effect, in milliseconds
            easing: 'ease-in-out', // CSS transition easing function

            // The "opener" function should return the element from which popup will be zoomed in
            // and to which popup will be scaled down
            // By defailt it looks for an image tag:
            opener: function (openerElement) {
              // openerElement is the element on which popup was initialized, in this case its <a> tag
              // you don't need to add "opener" option if this code matches your needs, it's defailt one.
              return openerElement.is('img') ? openerElement : openerElement.find('img');
            }
          }
        });
      }
    }
  };

  /**
   * Initialize main image magnific popup links.
   */
  Drupal.behaviors.articleImageMfp = {
    attach: function (context, settings) {
      if ($.isFunction($.fn.magnificPopup)) {
        if ($(".carousel-item .image").length > 0) {
          $(".carousel-item .image").once().each(function () {
            if ($(this).find("img").length > 0) {
              var popup_link = $(this).find("img").attr("src");
              popup_link = popup_link.replace(/^.*\/\/[^\/]+/, '');
              if (popup_link.includes("/s3/files/styles/")) {
                popup_link = popup_link.replace("/styles/article_page_main_image_fallback/public", "/styles/magnificpopuplarge/public");
              }
              else {
                popup_link = popup_link.replace(/\/s3fs(.*)public/g, "/s3/files/styles/magnificpopuplarge/public");
              }
              $(this).find("picture").wrap("<a class=\"popup-link\" href=\"" + popup_link + "\"></a>");

              // Simulate clicking on dynamic link when img is clicked. (For IE, FF to work without using jQuery wrap.)
              $(".carousel-item img").on("click", function () {
                $(this).prev().click();
              });
            }
          });

          $('.popup-link').magnificPopup({
            type: 'image',
            gallery: {
              enabled: true
            },
            image: {
              titleSrc: function (item) {
                return item.el.closest(".image").next().html() ? item.el.closest(".image").next().html() : "";
              }
            },
            zoom: {
              enabled: true, // By default it's false, so don't forget to enable it

              duration: 300, // duration of the effect, in milliseconds
              easing: 'ease-in-out', // CSS transition easing function

              // The "opener" function should return the element from which popup will be zoomed in
              // and to which popup will be scaled down
              // By defailt it looks for an image tag:
              opener: function (openerElement) {
                // openerElement is the element on which popup was initialized, in this case its <a> tag
                // you don't need to add "opener" option if this code matches your needs, it's defailt one.
                return openerElement.is('img') ? openerElement : openerElement.find('img');
              }
            }
          });
        }
      }
    }
  };

  /**
   * Splide carousel settings for widget.
   */
  Drupal.behaviors.initWidgetSplide = {
    attach: function (context, settings) {
      if (typeof Splide === "function") {
        if ($(".widget.splide:not(.is-initialized)").length > 0) {
          new Splide('.widget.splide:not(.is-initialized)', {
            type: "loop",
            perPage: 4,
            perMove: 4,
            arrows: false,
            gap: "1.5rem",
            autoplay: true,
            interval: 10000,
            breakpoints: {
              768: {
                perPage: 1,
                perMove: 1,
                gap: 0,
              },
              1024: {
                perPage: 2,
                perMove: 2,
              }
            }
          }).mount();
        }
      }
    }
  };

  /**
   * Make all card title links to target blank.
   */
  Drupal.behaviors.cardsLinkTargetBlank = {
    attach: function (context, settings) {
      $(".card .card-title > a").attr("target", "_blank");
      $(".block-title-url").attr("target", "_blank");
    }
  };

  /**
   * Initialize shareon js since we cant add init attribute on script tag.
   */
  Drupal.behaviors.initShareon = {
    attach: function (context, settings) {
      Shareon.init();
    }
  };

  /**
   * iFrame auto resizer.
   */
  Drupal.behaviors.iframeAutoResize = {
    attach: function (context, settings) {
      if (typeof iFrameResize === "function") {
        iFrameResize({
          checkOrigin: false,
        }, '.iframe-auto-resize');
      }
    }
  };

  /**
   * Custom GA Event for social icons on sticky navbar.
   */
  Drupal.behaviors.gaStickyNav = {
    attach: function (context, settings) {
      $(document).on('click', '#block-socialiconsblock .navbar-nav a', function () {
        if (!$(this).hasClass('dropdown-toggle')) {
          var label = $(this).attr('class').split(" ")[0];
          if (!$(this).hasClass('dropdown-item')) {
            label = $(this).attr('class').split(" ")[2];
          }
          customGAEvent($(this), "custom_event", "BT sticky subscribe bar", "click", label)
        }
      });
    }
  };


  /**
   * GA events for thrive pages elements.
   */
  Drupal.behaviors.gaTrackingThrivePages = {
    attach: function (context, settings) {
      //Social button GA tracking on thrive page.
      $('.thrive-box a').once().on('click', function () {
        if (typeof customGAEvent === "function") {
          customGAEvent($(this), "custom_event", "bt thrive article", "click", "button-social");
        }
      });

      //Thrive text CTA btn GA tracking
      $('a[href^="http://businesstimes.com.sg/thrive"]').once().on('click', function () {
        if (typeof customGAEvent === "function") {
          customGAEvent($(this), "custom_event", "bt thrive article", "click", "text-cta");
        }
      });
    }
  };

  // Function for GA event.
  function customGAEvent(element, event, category, action, label) {
    let options = {
      'event': event,
      'eventCategory': category,
      'eventAction': action,
      'eventLabel': label,
      'nonInteraction': false,
    }

    // Get abvariant from data attribute if there is.
    let abvariant = element.data("abvariant");
    if (abvariant) {
      options.abVariant = abvariant;
    }

    // Override the data attribute abvariant using _data.abvariant.
    if (typeof _data.abVariant !== 'undefined' && _data.abVariant) {
      options.abVariant = _data.abVariant;
    }

    window.dataLayer = window.dataLayer || [];
    window.dataLayer.push(options);
  }

  /**
   * Change toggler icon to X when dropdown is checked.
   */
  Drupal.behaviors.togglerIcon = {
    attach: function (context, settings) {
      $(".toggler > a[data-bs-toggle='collapse']").on("click", function () {
        if ($(this).hasClass("collapsed")) {
          $(this).html("<i class=\"fas fa-bars\"></i>");
        } else {
          $(this).html("<i class=\"fas fa-xmark\"></i>");
        }
      });
    }
  };

  /**
   * Hide/Show of grey navbar.
   */
  Drupal.behaviors.hideShowGreyNavbar = {
    attach: function (context, settings) {
      var lastScrollTop = 0;
      var threshold = 200;
      var $secondaryNav = $(".region-below-primary-menu");
      $(window, context).scroll(function (event) {
        var st = $(this).scrollTop();
        $secondaryNav.removeClass("collapsed");
        $(".block-title.sticky").addClass("with-greybar");

        if (st > lastScrollTop && st > threshold) {
          $secondaryNav.addClass("collapsed");
          $(".block-title.sticky").removeClass("with-greybar");
        }

        if (st > threshold) {
          lastScrollTop = st;
        }
      });
    }
  };

  /**
   * Add click event listener to subscribe links and modify the behavior based on user agent to support webview on mobile apps.
   */
  Drupal.behaviors.subscribeClick = {
    attach: function (context, settings) {
      $(document).ready(function () {

        // To handle primay subscribe button click on paywall.
        var primaryCta = document.getElementById("primary-cta-url");
        if (primaryCta) {
          primaryCta.addEventListener("click", subscribeClick);
          console.log("Adding subscribeClick evenet listener on primary CTA button");
        }

        // To handle secondary subscribe button click on paywall.
        var secondaryCta = document.getElementById("secondary-cta-url");
        if (secondaryCta) {
          secondaryCta.addEventListener("click", subscribeClick);
          console.log("Adding subscribeClick evenet listener on secondary CTA button");
        }

        // To handle subscribe link
        var sphSubscribeLinks = document.querySelectorAll('.sph-subscribe-link');
        sphSubscribeLinks.forEach(function (sphSubscribeLink) {
          sphSubscribeLink.addEventListener("click", subscribeClick);
          console.log("Adding subscribeClick evenet listener on subscribe link");
        });

        function subscribeClick(event) {
          event.preventDefault();
          // Get user agent string
          var userAgent = window.navigator.userAgent;

          // Get the subscription link
          var subscriptionLink = event.target.href;

          // Check if user agent is mobile
          if (userAgent.includes("com.sph.btiphone")) {
            window.open('btwebroute://present/subscribe');
          } else if (userAgent.includes("com.ps.bt")) {
            // Android webroute
            window.open('comlinks://bt/show?screen=subscribe');
          } else {
            window.open(subscriptionLink, "_blank");
          }
        }
      });
    }
  }

  /**
   * Add click event listener to login link/button and modify the behavior based on user agent to support webview on mobile apps.
   */
  Drupal.behaviors.loginClick = {
    attach: function (context, settings) {
      $(document).ready(function () {

        var loginLinks = document.querySelectorAll('a[onclick="_mySPHObj.openLogin()"]');

        // Add click event listener to anchor tags with onclick="_mySPHObj.openLogin()"
        loginLinks.forEach(function (loginLink) {
          loginLink.addEventListener("click", handleLoginClick);
          loginLink.removeAttribute("onclick");
        });

        // Function to handle login link click event
        function handleLoginClick(event) {
          event.preventDefault();

          // Get user agent string
          var userAgent = window.navigator.userAgent;

          // Check if user agent is mobile
          if (userAgent.includes('com.sph.btiphone')) {
            // iOS webroute
            window.open('btwebroute://present/login');
          } else {
            // Handle click event for regular website.
            _mySPHObj.openLogin();
          }
        }
      });
    }
  }

  /**
   * Add click event listener to logout link/button and modify the behavior based on user agent to support webview on mobile apps.
   */
  Drupal.behaviors.logoutClick = {
    attach: function (context, settings) {
      $(document).ready(function () {

        // Get anchor tags
        var logoutLinks = document.querySelectorAll('a[onclick="_mySPHObj.openLogout()"]');

        // Add click event listener to anchor tags with onclick="_mySPHObj.openLogout()"
        logoutLinks.forEach(function (logoutLink) {
          logoutLink.addEventListener("click", handleLogoutClick);
          logoutLink.removeAttribute("onclick");
        });

        // Function to handle login link click event
        function handleLogoutClick(event) {
          event.preventDefault();

          // Get user agent string
          var userAgent = window.navigator.userAgent;

          // Check if user agent is mobile
          if (userAgent.includes('com.sph.btiphone')) {
            // iOS webroute
            window.open('btwebroute://present/logout');
          } else {
            // Handle click event for regular website.
            _mySPHObj.openLogout();
          }
        }
      });
    }
  }
  /**
   * Enable tooltips.
   */
  Drupal.behaviors.enableTooltips = {
    attach: function (context, settings) {
      const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]')
      const tooltipList = [...tooltipTriggerList].map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl))
    }
  };

  /**
   * Check if element is in viewport.
   */
  Drupal.behaviors.breakingNewsAllCaughtup = {
    attach: function (context, settings) {
      const allCaughtUp = document.getElementById("allCaughtUp");
      $(window, context).on("scroll", function() {
        if(Drupal.elementIsVisibleInViewport(allCaughtUp, false) &&
        !allCaughtUp.classList.contains("in-view")) {
          allCaughtUp.classList.add("in-view");
        }
      });
    }
  };

  /**
   * Sticky Block title.
   */
  Drupal.behaviors.stickyBlockTitle = {
    attach: function (context, settings) {
      $(window, context).once().each(function() {
        if (typeof Sticky === "function") {
          var sticky = new Sticky('.block-title.sticky');
        }
      });
    }
  };

  /**
   * Breaking News page exposed filter form extra scripts.
   */
  Drupal.behaviors.breakingNewsPageExposedForm = {
    attach: function (context, settings) {
      const $form = $("#views-exposed-form-breaking-news-page-all", context);
      const $resetBtn = $form.find("button[value='Clear Filters']");
      const $applyBtn = $form.find("button[value='Apply']");
      const $fieldset = $form.find("fieldset");
      const $legend = $fieldset.find("legend");
      const $fieldsetContent = $fieldset.find(".fieldset-wrapper");
      const $formActions = $form.find(".form-actions");

      let filters = 0;
      let isFieldsetOpen = false;

      $legend.once().on("click", () => {
        if ($fieldset.hasClass("open")) {
          isFieldsetOpen = false;
          $fieldsetContent.slideUp(() => {
            $fieldset.removeClass("open");
            $("html, body").removeClass("modal-open");
          });

          if (filters > 0 && $(window).width() > 768) {
            $applyBtn.hide();
          } else {
            $formActions.slideUp();
          }
        } else {
          isFieldsetOpen = true;
          $fieldset.addClass("open");
          $fieldsetContent.slideDown();

          if (filters == 0) {
            $resetBtn.hide();
          }

          $formActions.slideDown({
            start: function() {
              $(this).css({
                display: "-webkit-box",
                display: "-ms-flexbox",
                display: "flex",
              });
            }
          });
          $applyBtn.show();
          $("html, body").addClass("modal-open");
        }
      });

      $form.find("input[type='checkbox']").once().on("change", function() {
        filters = 0;
        let total = $form.find('input[type=checkbox]:checked').length;
        let text  = total > 0 ? " ( " + total + " )" : null;
        $resetBtn.hide();
        $applyBtn.show();
        $legend.removeClass("hasFilters");
        $legend.find(".fieldset-legend").text("Filters");
        $("html, body").addClass("modal-open");

        if (text) {
          $legend.addClass("hasFilters");
          $legend.find(".fieldset-legend").text("Filters " + text);
          $resetBtn.show();
          filters = total;
        }
      });

      $applyBtn.once().on("click", function() {
        isFieldsetOpen = false;
        $fieldsetContent.slideUp(() => {
          $fieldset.removeClass("open");
          $("html, body").removeClass("modal-open");
        });

        if (filters > 0 && $(window).width() > 768) {
          $(this).hide();
        } else {
          $formActions.slideUp();
        }
      });

      $( document ).on( "ajaxComplete", function(event, xhr, settings) {
        if (settings.extraData && settings.extraData.view_name === "breaking_news_page") {
          $("html, body").animate({
            scrollTop: 0
          }, 30);
        }
      } );

      $(window).on("resize", function() {
        if (filters > 0 && $(this).width() > 768) {
          $formActions.show();
          $resetBtn.show()

          if (isFieldsetOpen) {
            $applyBtn.show();
          } else {
            $applyBtn.hide();
          }
        }
      });

      // $("body.modal-open::before", context).once().on("click", function() {
      //   $form.find("details").removeAttr("open");
      //   $("html, body").removeClass("modal-open");
      // });
    }
  };

})(jQuery, Drupal);
